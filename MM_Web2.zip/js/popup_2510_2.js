// Список активных попапов
//var ssc='<div class="subscribe"><form action="//micromoney.us16.list-manage.com/subscribe/post?u=baf855c4f25ef91d97dd211c6&amp;id=0615f09eba" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate=""><div class="input-wrap"><input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="email address" required=""><p localizerid="59d2f090a0624f4ad4889058">Type correct email</p></div><button type="submit" onclick="fbq(\'track\', \'CompleteRegistration\'); ga(\'send\', \'event\', \'Subscribe\', \'Subscribe mailchimp\');" localizerid="59d2f090a0624f4ad4889059">Subscribe now</button></form></div>';

var popd={
	
	
	
	/*	
	1:{
		'l':['ru','ko','en'], 				// lang list
		't':{
			'en':'popap html header1',
			'ru':'html Заголовок попапа1',
			},
		's':{
			'en':'popap html subtitle1',
			'ru':'html подпись заголовка1',
			},
		'b':{
			'en':'popap html body1',
			'ru':'html тело попапа1',
			},
	}
	,
	4:{
		'l':['ko'], 				// lang list
		'h':['630px'],
		't':{
			'ko':'MicroMoney 한국 고객께 ',
			},
		's':{
			'ko':'2017년 10월 24일 (화), 오후 9시 (GMT+9).',
			},
		'b':{
			'ko':'Micromoney 블록체인을 기반으로하는 최초의 신용 기록 부서에서는 한국 고객을 위해 처음으로 투명한 토큰 배포 캠페인과 관련한 웨비나를 진행할 예정입니다. 저희 회사는10 월 18 일에 토큰 배포 캠페인을 시작하였으며, 이미 780 만 달러 이상을 모금하였습니다! MicroMoney 프로젝트의 아이디어, 역사 및 향후 계획에 대해 알려 드리도록 하겠습니다. 관련된 숫자와 정보를 알려 드리면서 우리 비즈니스가 사실인 것을 증명할 것입니다. 우리는 왜 최초의 투명한 토큰 배포 캠페인이라고 하는지? 수입 및 경비에 대한 추가적인 정보를 어떻게 받을 수 있는지? 토큰이 어떻게 보호되고 있는지? 등 Telegram, Facebook 과 Twitter에서 자주하는 질문들에 대하여 답변하도록 하겠습니다! 당신이 알고 싶었던 모든 것을 알려 드리겠습니다! </br></br><a style="color:blue;" href="https://zoom.us/j/953277995" target="_blank">웨비나 일정: 2017년 10월 24일 (화), 오후 9시 (GMT+9).</a>',
			},
	}
	,
	5:{
		'l':['en'], 				// lang list
		//'h':['630px'], 
		't':{
			'en':'Introducing the AMM Token by MicroMoney',
			},
		's':{
			'en':'About our Token Model, its Legality and Profitability',
			},
		'b':{
			'en':'Welcome to MicroMoney’s Webinar, supporting the world’s first, fully transparent token distribution campaign. Today we will discuss the AMM token model, how it relates to the MicroMoney ecosystem, what our business expansion plans are, and how this affects token value.</br></br> You will also get the opportunity to meet Anton Dzyatkovsky, MicroMoney co-founder, and Vasily Sumanov, blockchain analyst and MicroMoney project advisor </br></br><a style="color:blue;" href="https://zoom.us/j/595621534" target="_blank">The Webinar begins at 15:00 (GMT) 27 October 2017.</a>',
			},
	}
	0:{
		// lang list - еmpty - for all
		//'h':['630px'], 
		'l':['en'],
		't':{
			'en':'Subscribe us',
			},
		's':{
			'en':'Subscribe dude pls',
			},
		'b':{
			'en':ssc,
			},
	}	
	 */ 
 
	
};